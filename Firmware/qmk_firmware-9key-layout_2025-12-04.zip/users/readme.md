# User space

This is a place for users to put code that they might use between keyboards. If you build the keymap `mine`, `/users/mine/rules.mk` will be included in your build, and `/users/mine/` will be in your path - keep these things in mind when naming your files and referencing them from other places.
