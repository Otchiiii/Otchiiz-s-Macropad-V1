// Copyright 2023 Stefan Kerkmann (@KarlK90)
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#include "test_common.h"

#define TAPPING_TERM 200
